package org.akka.essentials.supervisor.example3;

public class Result {

}
