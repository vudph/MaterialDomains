package akka.first.app.java.messages;

public class Result {

}
