package mongdb.ulti;

public interface MongoCollection {

	static final String SWITCH_COLLECTION = "Switch";
	static final String DEVICE_COLLECTION = "Device";
	static final String LOG_COLLECTION = "Log";
	static final String PORT_COLLECTION = "Port";
}
