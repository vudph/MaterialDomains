package mongodb.model;

import java.util.Date;
import java.util.List;

import mongdb.ulti.MongoCollection;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = MongoCollection.SWITCH_COLLECTION)
@CompoundIndexes({
		@CompoundIndex(def = "{'name' : 1, 'createDate' : -1}"),
		@CompoundIndex(def = "{'status' : 1, 'location' : 1}", name = "status_location")
})
public class Switch {

	@Id
	private ObjectId id;
	@Indexed(unique=true)
	private IPAddressInfo ipAddressInfo;
	@Indexed(unique=true)
	private String name;
	private String location;
	private String status;
	private List<SwitchPort> ports;
	private Date createDate;
	private Date modifiedDate;

	// getter & setter are omitted

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public IPAddressInfo getIpAddressInfo() {
		return ipAddressInfo;
	}

	public void setIpAddressInfo(IPAddressInfo ipAddressInfo) {
		this.ipAddressInfo = ipAddressInfo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<SwitchPort> getPorts() {
		return ports;
	}

	public void setPorts(List<SwitchPort> ports) {
		this.ports = ports;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "Switch [id=" + id + ", ipAddressInfo=" + ipAddressInfo
				+ ", location=" + location + ", status=" + status + ", name="
				+ name + ", ports=" + ports + ", createDate=" + createDate
				+ ", modifiedDate=" + modifiedDate + "]\n";
	}
}
