package mongodb.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Port")
public class Port {

	@Id
	private int id;
	private String namePort;
	private int portNumber;
	private Date createDate;
	private Date modifiedDate;
	private TypePort typePort;
	
	@DBRef
	private Device device;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNamePort() {
		return namePort;
	}

	public void setNamePort(String namePort) {
		this.namePort = namePort;
	}

	public int getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(int portNumber) {
		this.portNumber = portNumber;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public TypePort getTypePort() {
		return typePort;
	}

	public void setTypePort(TypePort typePort) {
		this.typePort = typePort;
	}

	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}
	
	@Override
	public String toString() {
		return "Port [id=" + id + ", namePort=" + namePort + ", portNumber="
				+ portNumber + ", createDate=" + createDate + ", modifiedDate="
				+ modifiedDate + ", typePort=" + typePort + ", device="
				+ device + "]";
	}
}
