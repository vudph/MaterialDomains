package mongodb.model;

public class SwitchPort {

	private int portNumber;
	private String portType;
	private String portStatus;
	
	public int getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(int portNumber) {
		this.portNumber = portNumber;
	}

	public String getPortType() {
		return portType;
	}

	public void setPortType(String portType) {
		this.portType = portType;
	}

	public String getPortStatus() {
		return portStatus;
	}

	public void setPortStatus(String portStatus) {
		this.portStatus = portStatus;
	}

	@Override
	public String toString() {
		return "SwitchPort [portNumber=" + portNumber + ", portType="
				+ portType + ", portStatus=" + portStatus + "]";
	}
	
}
