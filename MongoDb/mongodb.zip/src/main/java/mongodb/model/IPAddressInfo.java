package mongodb.model;

public class IPAddressInfo {

	private String ipAddress;
	private String ipMask;
	
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getIpMask() {
		return ipMask;
	}
	public void setIpMask(String ipMask) {
		this.ipMask = ipMask;
	}
	@Override
	public String toString() {
		return "IPAddressInfo [ipAddress=" + ipAddress + ", ipMask=" + ipMask
				+ "]";
	}
}
