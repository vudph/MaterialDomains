package mongodb.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Log")
public class Log {
	
	private Date createAt;
	private String logType;
	private String logMessage;
	
	public Date getCreateAt() {
		return createAt;
	}
	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}
	public String getLogType() {
		return logType;
	}
	public void setLogType(String logType) {
		this.logType = logType;
	}
	public String getLogMessage() {
		return logMessage;
	}
	public void setLogMessage(String logMessage) {
		this.logMessage = logMessage;
	}
	@Override
	public String toString() {
		return "Log [createAt=" + createAt + ", logType=" + logType
				+ ", logMessage=" + logMessage + "]\n";
	}
}
