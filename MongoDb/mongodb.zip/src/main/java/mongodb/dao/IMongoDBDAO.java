package mongodb.dao;

import java.util.Date;
import java.util.List;

import mongodb.model.Log;
import mongodb.model.Switch;

public interface IMongoDBDAO {
	
	// index examples

	void createIndex();
	
	void getIndex();
	
	void dropIndex();
	
	void insertLogForTest();
	
	List<Log> findLogs(Date createAt);
	
	// read operators examples
	
	List<Switch> ltOperator();
	
	List<Switch> ltOperatorUseRepo();
	
	List<Switch> gtOperator();
	
	List<Switch> gtOperatorUseRepo();
	
	List<Switch> lteOperator();
	
	List<Switch> lteOperatorUseRepo();
	
	List<Switch> gteOperator();
	
	List<Switch> gteOperatorUseRepo();
	
	List<Switch> inOperator();
	
	List<Switch> inOperatorUseRepo();
	
	List<Switch> ninOperator();
	
	List<Switch> ninOperatorUseRepo();
	
	List<Switch> neOperator();
	
	List<Switch> neOperatorUseRepo();
	
	List<Switch> orOperator();
	
	List<Switch> orOperatorUseRepo();
	
	List<Switch> andOperator();
	
	List<Switch> andOperatorUseRepo();
	
	List<Switch> notOperator();
	
	List<Switch> notOperatorUseRepo();
	
	List<Switch> norOperator();
	
	List<Switch> norOperationUseRepo();
	
	List<Switch> existsOperator();
	
	List<Switch> existsOperationUseRepo();
	
	List<Switch> typeOperator();
	
	List<Switch> typeOperationUseRepo();
	
	List<Switch> sizeOperator();
	
	List<Switch> sizeOperationUseRepo();
	
	List<Switch> regexOperator();
	
	List<Switch> regexOperationUseRepo();
	
	// update operators examples
	
	void renameOperator();
	
	void setOperator();
	
	void unsetOperator();
	
	void incOperator();
	
	void popOperator();
	
	void pullAllOperator();
	
	void pushOperator();
	
	void pullOperator();
	
	void addToSetOperator();
}
