package mongodb.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import mongodb.model.Device;
import mongodb.model.Log;
import mongodb.model.Switch;
import mongodb.reporitories.LogRepository;
import mongodb.reporitories.SwitchRepository;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.IndexOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexInfo;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.core.query.Update.Position;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoException;

public class MongoDBDAOImpl implements IMongoDBDAO {
	private MongoTemplate mongoTemplate;
	private LogRepository logRepository;
	private SwitchRepository switchRepository;

	public MongoDBDAOImpl(MongoTemplate mongoTemplate,
			LogRepository logRepository, SwitchRepository switchRepository) {
		this.mongoTemplate = mongoTemplate;
		this.logRepository = logRepository;
		this.switchRepository = switchRepository;
	}

	@Override
	public void createIndex() {
		// 1. Get IndexOperations from Device document
		IndexOperations indexOps = mongoTemplate.indexOps(Device.class);
		// 2. Create an index object
		Index index = new Index();
		index.on("ipAddress", Direction.ASC);
		index.named("ipAddress");
		index.unique();
		// 3. Create an index in Device document
		indexOps.ensureIndex(index);
	}

	@Override
	public void getIndex() {
		// 1. Get IndexOperations from Device document
		IndexOperations indexOps = mongoTemplate.indexOps(Device.class);
		// 2. Create all indexes
		List<IndexInfo> indexes = indexOps.getIndexInfo();
		for (IndexInfo indexInfo : indexes) {
			// 3. Process for each index
			System.out.println(indexInfo.toString());
		}
	}

	@Override
	public void dropIndex() {
		// 1. Get IndexOperations from Device document
		IndexOperations indexOps = mongoTemplate.indexOps(Device.class);
		// 2. Drop IpAddress index
		indexOps.dropIndex("ipAddress");
	}

	@Override
	public void insertLogForTest() {
		Log log = new Log();
		for (int i = 1; i < 3000; i++) {
			log.setCreateAt(new Date());
			log.setLogMessage("Message " + i);
			log.setLogType("Success");
			logRepository.save(log);
		}
	}

	@Override
	public List<Log> findLogs(Date createAt) {
		Query query = new Query();
		query.addCriteria(Criteria.where("createAt").gt(createAt));
		query.with(new Sort(Direction.ASC, "createAt"));
		return mongoTemplate.find(query, Log.class);
	}

	// Example for read operators

	public List<Switch> ltOperator() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-02-01");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("createDate").lt(date);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> ltOperatorUseRepo() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-02-01");
			// 2. Query result by using switchRepository
			return switchRepository.ltOperator(date);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> gtOperator() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-02-01");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("createDate").gt(date);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> gtOperatorUseRepo() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-02-01");
			// 2. Query result by using switchRepository
			return switchRepository.gtOperator(date);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> lteOperator() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-01-22");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("createDate").lte(date);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> lteOperatorUseRepo() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-1-22");
			// 2. Query result by using switchRepository
			return switchRepository.lteOperator(date);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> gteOperator() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-03-22");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("createDate").gte(date);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> gteOperatorUseRepo() {
		try {
			// 1. Create date to query
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse("2014-03-22");
			// 2. Query result by using switchRepository
			return switchRepository.gteOperator(date);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		} catch (ParseException e) {
			// Return null list if occur exception
			System.out.println("Parse Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> inOperator() {
		try {
			// 1. Create ipAddress array
			ArrayList<String> ips = new ArrayList<String>();
			ips.add("10.1.1.1");
			ips.add("10.1.1.2");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("ipAddressInfo.ipAddress").in(ips);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> inOperatorUseRepo() {
		try {
			// 1. Create ipAddress array
			ArrayList<String> ips = new ArrayList<String>();
			ips.add("10.1.1.1");
			ips.add("10.1.1.2");
			// 2. Query result by using switchRepository
			return switchRepository.inOperator(ips);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> ninOperator() {
		try {
			// 1. Create ipAddress array
			ArrayList<String> ips = new ArrayList<String>();
			ips.add("10.1.1.1");
			ips.add("10.1.1.2");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("ipAddressInfo.ipAddress").nin(ips);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> ninOperatorUseRepo() {
		try {
			// 1. Create ipAddress array
			ArrayList<String> ips = new ArrayList<String>();
			ips.add("10.1.1.1");
			ips.add("10.1.1.2");
			// 2. Query result by using switchRepository
			return switchRepository.ninOperator(ips);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> neOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("status").ne("Active");
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> neOperatorUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.neOperator("Active");
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> orOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.orOperator(
					Criteria.where("ipAddressInfo.ipAddress").is("10.1.1.1"),
					Criteria.where("ipAddressInfo.ipAddress").is("10.1.1.3"));
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> orOperatorUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.orOperator("10.1.1.1", "10.1.1.3");
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> andOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.andOperator(Criteria.where("status").is("Active"),
					Criteria.where("location").is("Lab4"));
			/**
			 * You also use $and operator like:
			 * criteria.and("status").is("Active");
			 * criteria.and("location").is("Lab4");
			 **/
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> andOperatorUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.andOperator("Active", "Lab4");
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> notOperator() {
		try {
			// 1. Create ipAddress array
			ArrayList<String> ips = new ArrayList<String>();
			ips.add("10.1.1.1");
			ips.add("10.1.1.2");
			// 2. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("ipAddressInfo.ipAddress").not().in(ips);
			// 3. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 4. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> notOperatorUseRepo() {
		try {
			// 1. Create ipAddress array
			ArrayList<String> ips = new ArrayList<String>();
			ips.add("10.1.1.1");
			ips.add("10.1.1.2");
			// 2. Query result by using switchRepository
			return switchRepository.notOperator(ips);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> norOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.norOperator(
					Criteria.where("ipAddressInfo.ipAddress").is("10.1.1.1"),
					Criteria.where("ipAddressInfo.ipAddress").is("10.1.1.2"));
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> norOperationUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.norOperator("10.1.1.1", "10.1.1.2");
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> existsOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("ipAddressInfo.ipMask").exists(true);
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> existsOperationUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.existsOperator(true);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> typeOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("createDate").type(9);
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> typeOperationUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.typeOperator(9);
			// 9 is type of date in MongoDB
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> sizeOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.and("ports").size(3);
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> sizeOperationUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.sizeOperator(3);
			// 9 is type of date in MongoDB
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> regexOperator() {
		try {
			// 1. Build criteria for query
			Criteria criteria = new Criteria();
			criteria.regex("S*[2-4]");
			// 2. Create query object
			Query query = new Query();
			query.addCriteria(criteria);
			// 3. Query result by using mongoTemplate
			return mongoTemplate.find(query, Switch.class);
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	public List<Switch> regexOperationUseRepo() {
		try {
			// 1. Query result by using switchRepository
			return switchRepository.regexOperator("S*[2-4]");
			// 9 is type of date in MongoDB
		} catch (MongoException e) {
			// Return null list if occur exception
			System.out.println("Mongo Exc: " + e.getMessage());
			return Collections.<Switch> emptyList();
		}
	}

	// ----------------------------------------------------------- //
	// Example for update operators

	public void renameOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("_id").exists(true));
			// 2. Build update object
			Update update = new Update();
			update.rename("modifiedDate", "lastUpdate");
			// 3. Update by using mongoTemplate
			mongoTemplate.updateMulti(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void setOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			BasicDBObject element1 = new BasicDBObject();
			element1.put("station", "Mac A");
			element1.put("port", "1");
			element1.put("vlan", "100");
			BasicDBObject element2 = new BasicDBObject();
			element2.put("station", "Mac B");
			element2.put("port", "2");
			element2.put("vlan", "100");
			BasicDBObject element3 = new BasicDBObject();
			element3.put("station", "Mac C");
			element3.put("port", "3");
			element3.put("vlan", "200");
			BasicDBObject element4 = new BasicDBObject();
			element3.put("station", "Mac D");
			element3.put("port", "4");
			element3.put("vlan", "200");
			ArrayList<BasicDBObject> value = new ArrayList<BasicDBObject>();
			value.add(element1);
			value.add(element2);
			value.add(element3);
			value.add(element4);
			Update update = new Update();
			update.set("switchTable", value);
			// 3. Update by using mongoTemplate
			mongoTemplate.updateMulti(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void unsetOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			Update update = new Update();
			update.unset("description");
			// 3. Update by using mongoTemplate
			mongoTemplate.updateMulti(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void incOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			Update update = new Update();
			update.inc("switchTable.0.vlan", 100);
			// 3. Update by using mongoTemplate
			mongoTemplate.updateMulti(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void popOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			Update update = new Update();
			update.pop("switchTable", Position.FIRST);
			// 3. Update by using mongoTemplate
			mongoTemplate.updateFirst(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void pullAllOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			BasicDBObject element2 = new BasicDBObject();
			element2.put("station", "Mac B");
			element2.put("port", "2");
			element2.put("vlan", "100");
			BasicDBObject element3 = new BasicDBObject();
			element3.put("station", "Mac C");
			element3.put("port", "3");
			element3.put("vlan", "200");
			ArrayList<BasicDBObject> value = new ArrayList<BasicDBObject>();
			value.add(element2);
			value.add(element3);
			Update update = new Update();
			update.pullAll("switchTable", value.toArray());
			// 3. Update by using mongoTemplate
			mongoTemplate.updateFirst(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void pushOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			BasicDBObject value = new BasicDBObject();
			value.put("station", "Mac B");
			value.put("port", "2");
			value.put("vlan", "100");
			Update update = new Update();
			update.push("switchTable", value);
			// 3. Update by using mongoTemplate
			mongoTemplate.updateFirst(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	/*
	 * public void pushWithModifiersOperator1() { try { // 1. Select all
	 * documents in database to update Criteria criteria = new Criteria();
	 * criteria.and("switchTable.port"). Query query = new Query();
	 * query.addCriteria(); // 2. Build update object BasicDBObject element1 =
	 * new BasicDBObject(); element1.put("station", "Mac A");
	 * element1.put("port", "1"); element1.put("vlan", "100"); BasicDBObject
	 * element2 = new BasicDBObject(); element2.put("station", "Mac B");
	 * element2.put("port", "2"); element2.put("vlan", "100"); BasicDBObject
	 * element3 = new BasicDBObject(); element3.put("station", "Mac C");
	 * element3.put("port", "3"); element3.put("vlan", "200"); Update update =
	 * new Update(); update.push("switchTable").each(element1, element2,
	 * element3); // 3. Update by using mongoTemplate
	 * mongoTemplate.updateFirst(query, update, Switch.class); } catch
	 * (MongoException e) { System.out.println("Mongo Exc: " + e.getMessage());
	 * } }
	 */

	public void pullOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			BasicDBObject value = new BasicDBObject();
			value.append("vlan", 200);
			Update update = new Update();
			update.pull("switchTable", value);
			// 3. Update by using mongoTemplate
			mongoTemplate.updateFirst(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}

	public void addToSetOperator() {
		try {
			// 1. Select all documents in database to update
			Query query = new Query();
			query.addCriteria(Criteria.where("name").is("Switch1"));
			// 2. Build update object
			BasicDBObject value = new BasicDBObject();
			value.put("station", "Mac B");
			value.put("port", "2");
			value.put("vlan", "100");
			Update update = new Update();
			update.addToSet("switchTable", value);
			// 3. Update by using mongoTemplate
			mongoTemplate.updateFirst(query, update, Switch.class);
		} catch (MongoException e) {
			System.out.println("Mongo Exc: " + e.getMessage());
		}
	}
}
