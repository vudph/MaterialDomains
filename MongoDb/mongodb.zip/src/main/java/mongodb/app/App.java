package mongodb.app;

import java.text.ParseException;

import mongodb.dao.IMongoDBDAO;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * This class use for testing examples in document
 * 
 */

public class App {

	private static ClassPathXmlApplicationContext classPathXmlApplicationContext;

	public static void main(String[] args) throws ParseException {
		classPathXmlApplicationContext = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		IMongoDBDAO mongodbDAO = classPathXmlApplicationContext
				.getBean("mongodbDAO", IMongoDBDAO.class);
		
		//1. Test create index
		/*
		mongodbDAO.createIndex();
		mongodbDAO.getIndex();
		*/
		
		//2. Test drop index
		/*
		mongodbDAO.dropIndex();
		mongodbDAO.getIndex();
		*/
		
		//3. Test speed of query
		
		/*Long start, end;
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
		Date date = sdf.parse("2014-07-21");

		// Time before processing query in milliseconds
		start = System.currentTimeMillis();
		// Query method
		mongodbDAO.findLogs(date);
		// Time in completing query method
		end = System.currentTimeMillis();

		System.out.println("Take " + (end - start) + " miliseconds.");
		*/
		
		// 4. Test operator $lt
		/*
		System.out.println(mongodbDAO.ltOperator());
		System.out.println(mongodbDAO.ltOperatorUseRepo());
		*/
		
		// 5. Test operator $gt
		/*
		System.out.println(mongodbDAO.gtOperator());
		System.out.println(mongodbDAO.gtOperatorUseRepo());
		*/
		
		// others test by yourself
	}
}
