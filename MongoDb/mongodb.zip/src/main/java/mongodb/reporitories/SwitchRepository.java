package mongodb.reporitories;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mongodb.model.Switch;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SwitchRepository extends MongoRepository<Switch, ObjectId>{

	@Query(value="{'$and' : ["
			+ "{'status' : ?0},"
			+ "{'ports' : {'$size' : ?1}},"
			+ "{'ipAddressInfo.ipAddress' : {'$in' : ?2}},"
			+ "{'createDate' : {'$lt' : ?3}}"
			+ "]}")
	List<Switch> getSwitches(String status, int sizeOfPort, ArrayList<String> ips, Date date);
	
	@Query(value="{'$and' : ["
			+ "{'ports' : {'$size' : ?0}},"
			+ "{'ipAddressInfo.ipAddress' : {'$ne' : ?1}},"
			+ "{'createDate' : {'$exists' : true}},"
			+ "{'createDate' : {'$type' : ?2}},"
			+ "{'modifiedDate' : {'$exists' : true}},"
			+ "{'modifiedDate' : {'$type' : ?2}}"
			+ "]}")
	List<Switch> getSwitches(int sizeOfPort, String notIpAddress, int type);
	
	@Query(value="{'$nor' : ["
			+ "{'status' : ?0},"
			+ "{'ipAddressInfo.ipAddress' : {'$in' : ?1}},"
			+ "{'location' : {'$ne' : ?2}}"
			+ "]}")
	List<Switch> getSwitches(String notStatus, ArrayList<String> notIps, String location);
	
	@Query(value="{'$and' : ["
			+ "{'ipAddressInfo.ipMask' : {'$regex' : ?0}},"
			+ "{'ipAddressInfo.ipAddress' : {'$regex' : ?1}},"
			+ "]}")
	List<Switch> getSwitches(String maskPattern, String ipPattern);
	
	@Query(value="{'createDate' : {'$lt' : ?0}}")
	List<Switch> ltOperator(Date date);
	
	@Query(value="{'createDate' : {'$gt' : ?0}}")
	List<Switch> gtOperator(Date date);
	
	@Query(value="{'createDate' : {'$lte' : ?0}}")
	List<Switch> lteOperator(Date date);
	
	@Query(value="{'createDate' : {'$gte' : ?0}}")
	List<Switch> gteOperator(Date date);
	
	@Query(value="{'ipAddressInfo.ipAddress'} : {'$in' : ?0}")
	List<Switch> inOperator(ArrayList<String> ips);
	
	@Query(value="{'ipAddressInfo.ipAddress'} : {'$nin' : ?0}")
	List<Switch> ninOperator(ArrayList<String> ips);
	
	@Query(value="{'status' : {'$ne' : ?0}}")
	List<Switch> neOperator(String status);
	
	@Query(value="{'$or' : [{'ipAddressInfo.ipAddress' : ?0},"
			+ "{'ipAddressInfo.ipAddress' : ?1}]}")
	List<Switch> orOperator(String ip1, String ip2);
	
	@Query(value="{'$and' : [{'status' : 'Active'},"
			+ "{'location' : 'Lab4'}]}")
	List<Switch> andOperator(String status, String location);
	
	@Query(value="{'ipAddressInfo.ipAddress' : {'$not' : {'$in' : ?0}}}")
	List<Switch> notOperator(ArrayList<String> ips);
	
	@Query(value="{'$nor' : [{'ipAddressInfo.ipAddress' : ?0},"
			+ "{'ipAddressInfo.ipAddress' : ?1}]}")
	List<Switch> norOperator(String ip1, String ips2);
	
	@Query(value="{'ipAddressInfo.ipMask' : {'$exists' : ?0}}")
	List<Switch> existsOperator(boolean isMaks);
	
	@Query(value="{'createDate' : {'$type' : ?0}}")
	List<Switch> typeOperator(int typeCode);
	
	@Query(value="{'ports' : {'$size' : ?0}}")
	List<Switch> sizeOperator(int numberOfElements);
	
	@Query(value="{'name' : {'$regex' : ?0}}")
	List<Switch> regexOperator(String pattern);
}
