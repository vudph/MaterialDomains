package mongodb.reporitories;

import mongodb.model.Port;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PortRepository extends MongoRepository<Port, Integer>{

}
